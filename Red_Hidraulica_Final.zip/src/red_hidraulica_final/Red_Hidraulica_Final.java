/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package red_hidraulica_final;

import Clases.Bombas_de_agua;
import Clases.Cisterna;
import Clases.Cisternas_compuestas;
import Clases.Cisternas_simples;
import Clases.Deposito;
import Clases.MiExcepcion;
import Clases.Tanque;
import Clases.Turbina;

/**
 *
 * @author CasinerO
 */
public class Red_Hidraulica_Final {

    //Arreglos    
    private Deposito[] arrayDepositos = new Deposito[0];
    private Bombas_de_agua[] arrayBombas_agua = new Bombas_de_agua[0];
    private Turbina[] arrayTurbinas = new Turbina[0];

    private int cantRealTanques;
    private int cantRealCisternas;    
    private int cantRealTurbinas;
    private int cantRealBombas;
    

    public Red_Hidraulica_Final() {

        this.cantRealTanques = 0;
        this.cantRealCisternas = 0;        
        this.cantRealTurbinas = 0;
        this.cantRealBombas = 0;
        
    }

    //Metodos Para los Tanques
    public String tanque_disponible() {

        int contador = 0;

        for (int i = 0; i < arrayDepositos.length; i++) {
            if (arrayDepositos[i] instanceof Tanque && arrayDepositos[i].getEstado().equals("disponible")) {
                contador++;
            }
        }
        return "" + contador + "";
    }

    public boolean tanque_estadoMalRegular(String tipo_abasto, Deposito item) {

        if (item instanceof Tanque) {
            if (item.getEstado().equals("mal") || item.getEstado().equals("regular")) {
                if (item.getTipo_abasto().equals(tipo_abasto)) {
                    return true;
                }
            }
        }

        return false;
    }

    public void adicionarTanque(Tanque nuevo){
        this.Redimencionar();
      
        arrayDepositos[arrayDepositos.length - 1] = nuevo;
        cantRealTanques++;
    }

    public boolean saberSiEsTanque(Deposito item) {

        if (item instanceof Tanque) {
            return true;
        }

        return false;
    }

    
    
    public int numeroTanque(){
        
        return 0;
    }

    //---Redimencionar el arreglo de Depositos 
    public void Redimencionar() {

        Deposito[] depositosAux = new Deposito[arrayDepositos.length + 1];

        for (int i = 0; i < arrayDepositos.length; i++) {

            depositosAux[i] = arrayDepositos[i];
        }
        arrayDepositos = depositosAux;

    }

    // END Metodos para los tanques
    
    //Metodos para los Turbinas
    public String turbinas_disponibles() {

        int contador = 0;

        for (int i = 0; i < arrayTurbinas.length; i++) {
            if (arrayTurbinas[i] instanceof Turbina && arrayTurbinas[i].getEstado().equals("disponible")) {
                contador++;
            }
        }
        return "" + contador + "";
    }

    public Turbina[] estado_Turbina_mayor_fuerza() throws MiExcepcion{
                
        int mayorFuerza = 500;
        
        
        Turbina[] turbinasReturn = new Turbina[500];
        
        //Busco la mayor fuerza
        for (int i = 0; i < arrayTurbinas.length; i++) {
            if (arrayTurbinas[i].getFuerza() >= mayorFuerza) {
                turbinasReturn[i] = arrayTurbinas[i];
                
            }
        }

        //Cuento cuantas cumplen la condicion
//        for (int i = 0; i < arrayTurbinas.length; i++) {
//            if (arrayTurbinas[i].getFuerza() >= mayorFuerza) {
//                    
//            }
//        }

       // Turbina[] turbinasReturn = new Turbina[contador];

    
        
        if (turbinasReturn.length == 0){
            throw new MiExcepcion ("No hay turbinas para mostrar");
        }
        return turbinasReturn;
    }

    public void adicionarTurbina(Turbina nuevo) {
        this.RedimencionarTurbinas();
        arrayTurbinas[arrayTurbinas.length - 1] = nuevo;
        cantRealTurbinas++;
    }

    //---Redimencionar el arreglo de Turbinas 
    public void RedimencionarTurbinas() {

        Turbina[] turbinasAux = new Turbina[arrayTurbinas.length + 1];

        for (int i = 0; i < arrayTurbinas.length; i++) {

            turbinasAux[i] = arrayTurbinas[i];
        }
        arrayTurbinas = turbinasAux;

    }

    public Turbina[] turbinas_mayor_regimen_Bombeo() {

        //String estadoTurbinaMayorFuerza;
        int mayorRegimen = arrayTurbinas[0].getRegimen();

        int contador = 0;
        int contadorIterador = 0;

        //Busco el mayor regimen de bombe
        for (int i = 1; i < arrayTurbinas.length; i++) {
            if (arrayTurbinas[i].getRegimen() >= mayorRegimen) {
                mayorRegimen = arrayTurbinas[i].getRegimen();
            }
        }

        //Cuento cuantas cumplen la condicion
        for (int i = 0; i < arrayTurbinas.length; i++) {
            if (arrayTurbinas[i].getRegimen() >= mayorRegimen) {
                contador++;
            }
        }

        Turbina[] turbinasReturn = new Turbina[contador];

        for (int i = 0; i < arrayTurbinas.length; i++) {
            if (arrayTurbinas[i].getRegimen() >= mayorRegimen) {
                turbinasReturn[contadorIterador] = arrayTurbinas[i];
                contadorIterador++;
            }
        }

        return turbinasReturn;
    }
    

    // END Metodos para los Turbinas    
    //Metodos para los Bombas de Agua  
    public String bombas_de_agua_disponibles() {

        int contador = 0;

        for (int i = 0; i < arrayBombas_agua.length; i++) {
            if (arrayBombas_agua[i] instanceof Bombas_de_agua && arrayBombas_agua[i].getEstado().equals("disponible")) {
                contador++;
            }
        }
        return "" + (contador) + "";
    }

    public double tiempo_Promedio_Bombeo_Bombas_BuenEstado() {

        int sumaTiempoBombeo = 0;
        
        int contador = 0;

        for (int i = 0; i < arrayBombas_agua.length; i++) {
            if (arrayBombas_agua[i].getEstado().equals("disponible")) {
                sumaTiempoBombeo += arrayBombas_agua[i].getTiempo_bombeo();
                contador++;
            }
        }

        double tiempoPromedio = sumaTiempoBombeo / contador;

        return tiempoPromedio;
    }

    public void adicionarBomba(Bombas_de_agua nuevo) {
        this.RedimencionarBomba();
        arrayBombas_agua[arrayBombas_agua.length - 1] = nuevo;
        cantRealBombas++;
    }

    public boolean bombas_disponible(Turbina item) {

        if (item.getEstado().equals("disponible")) {
            return true;
        }
        return false;
    }

    //---Redimencionar el arreglo de Turbinas 
    public void RedimencionarBomba() {

        Bombas_de_agua[] bombasAux = new Bombas_de_agua[arrayBombas_agua.length + 1];

        for (int i = 0; i < arrayBombas_agua.length; i++) {

            bombasAux[i] = arrayBombas_agua[i];
        }
        arrayBombas_agua = bombasAux;

    }

    public Bombas_de_agua[] bombas_mayor_regimen_Bombeo() {

        //String estadoTurbinaMayorFuerza;
        int mayorRegimen = arrayBombas_agua[0].getRegimen();

        int contador = 0;
        int contadorIterador = 0;

        //Busco el mayor regimen de bombe
        for (int i = 1; i < arrayBombas_agua.length; i++) {
            if (arrayBombas_agua[i].getRegimen() >= mayorRegimen) {
                mayorRegimen = arrayBombas_agua[i].getRegimen();
            }
        }

        //Cuento cuantas cumplen la condicion
        for (int i = 0; i < arrayBombas_agua.length; i++) {
            if (arrayBombas_agua[i].getRegimen() >= mayorRegimen) {
                contador++;
            }
        }

        Bombas_de_agua[] bombasReturn = new Bombas_de_agua[contador];

        for (int i = 0; i < arrayBombas_agua.length; i++) {
            if (arrayBombas_agua[i].getRegimen() >= mayorRegimen) {
                bombasReturn[contadorIterador] = arrayBombas_agua[i];
                contadorIterador++;
            }
        }

        return bombasReturn;
    }

    // END Metodos para los Bombas de Agua
    //Metodos para los Cisternas 
    public String cisterna_disponibles() {

        int contador = 0;

        for (int i = 0; i < arrayDepositos.length; i++) {
            if (arrayDepositos[i] instanceof Cisternas_simples && arrayDepositos[i].getEstado().equals("disponible")) {
                contador++;
            } else if (arrayDepositos[i] instanceof Cisternas_compuestas && arrayDepositos[i].getEstado().equals("disponible")) {
                contador++;
            }
        }
        return "" + contador + "";
    }

    public void adicionarCisterna(Cisterna nuevo) {
        this.RedimencionarCisterna();
        arrayDepositos[arrayDepositos.length - 1] = nuevo;
        cantRealCisternas++;
    }

    //---Redimencionar el arreglo de Depositos 
    public void RedimencionarCisterna() {

        Deposito[] depositosAux = new Deposito[arrayDepositos.length + 1];

        for (int i = 0; i < arrayDepositos.length; i++) {

            depositosAux[i] = arrayDepositos[i];
        }
        arrayDepositos = depositosAux;

    }

    public boolean saberSiEsCisternaSimple(Deposito item) {

        if (item instanceof Cisternas_simples) {
            return true;
        }
        return false;
    }

    public boolean saberSiEsCisternaCompuesta(Deposito item) {

        if (item instanceof Cisternas_compuestas) {
            return true;
        }
        return false;
    }

    public boolean cisternasSimples_estadoMalRegular(String tipo_abasto, Deposito item) {

        if (item instanceof Cisternas_simples) {
            if (item.getEstado().equals("mal") || item.getEstado().equals("regular")) {
                if (item.getTipo_abasto().equals(tipo_abasto)) {
                    return true;
                }
            }
        }

        return false;
    }

    public boolean cisternaCompuesta_estadoMalRegular(String tipo_abasto, Deposito item) {

        if (item instanceof Cisternas_compuestas) {
            if (item.getEstado().equals("mal") || item.getEstado().equals("regular")) {
                if (item.getTipo_abasto().equals(tipo_abasto)) {
                    return true;
                }
            }
        }

        return false;
    }

    public int capacidadTotalCisterna(String forma, int cantCompartimientos) {

        int sumador = 0;

        Deposito[] items = this.getArrayDepositos();

        for (int i = 0; i < items.length; i++) {

            if (saberSiEsCisternaSimple(items[i]) == true) {
                Cisternas_simples item = (Cisternas_simples) items[i];

                if (item.getForma().equals(forma)) {
                    sumador += items[i].getCapacidad();
                }

            } else if (saberSiEsCisternaCompuesta(items[i]) == true) {
                Cisternas_compuestas item = (Cisternas_compuestas) items[i];

                if (item.getCantidad_compartimientos() == cantCompartimientos) {
                    sumador += items[i].getCapacidad();
                }
            }
        }

        return sumador;
    }

    // END Metodos para los Cisternas   
    
    //BEGIN Getter Y Setter de los array
    public Deposito[] getArrayDepositos() {
        return arrayDepositos;
    }

    public void setArrayDepositos(Tanque[] arrayDepositos) {
        this.arrayDepositos = arrayDepositos;
    }

    public Bombas_de_agua[] getArrayBombas_agua() {
        return arrayBombas_agua;
    }

    public void setArrayBombas_agua(Bombas_de_agua[] arrayBombas_agua) {
        this.arrayBombas_agua = arrayBombas_agua;
    }

    public Turbina[] getArrayTurbinas() {
        return arrayTurbinas;
    }

    public void setArrayTurbinas(Turbina[] arrayTurbinas) {
        this.arrayTurbinas = arrayTurbinas;
    }

    //END Getter Y Setter de los array 
    
    //BEGIN Getter y Setter de las CantReal
    public int getCantRealTanques() {
        return cantRealTanques;
    }

    public void setCantRealTanques(int cantRealTanques) {
        this.cantRealTanques = cantRealTanques;
    }

    public int getCantRealCisternas() {
        return cantRealCisternas;
    }

    public void setCantRealCisternas(int cantRealCisternas) {
        this.cantRealCisternas = cantRealCisternas;
    }

    public int getCantRealTurbinas() {
        return cantRealTurbinas;
    }

    public void setCantRealTurbinas(int cantRealTurbinas) {
        this.cantRealTurbinas = cantRealTurbinas;
    }

    public int getCantRealBombas() {
        return cantRealBombas;
    }

    public void setCantRealBombas(int cantRealBombas) {
        this.cantRealBombas = cantRealBombas;
    }
    
    //END Getter y Setter de las CantReal
    

    public void GenerarDatosAplicacion() {

        //Generr Tanques
        Tanque nuevo1 = new Tanque("Metal", 100, "disponible", "Diario");
        this.adicionarTanque(nuevo1);
        Tanque nuevo2 = new Tanque("Fibrocemento", 100, "disponible", "Diario");
        this.adicionarTanque(nuevo2);
        Tanque nuevo3 = new Tanque("Fibrocemento", 100, "mal", "Diario");
        this.adicionarTanque(nuevo3);
        Tanque nuevo4 = new Tanque("Fibrocemento", 300, "mal", "Diario");
        this.adicionarTanque(nuevo4);
        Tanque nuevo5 = new Tanque("Fibrocemento", 300, "mal", "Semanal");
        this.adicionarTanque(nuevo5);
        Tanque nuevo6 = new Tanque("Plastico", 300, "regular", "Semanal");
        this.adicionarTanque(nuevo6);
        Tanque nuevo7 = new Tanque("Plastico", 600, "regular", "Semanal");
        this.adicionarTanque(nuevo7);
        Tanque nuevo8 = new Tanque("Metal", 600, "regular", "Quincenal");
        this.adicionarTanque(nuevo8);
        Tanque nuevo9 = new Tanque("Metal", 1000, "no disponible", "Quincenal");
        this.adicionarTanque(nuevo9);
        Tanque nuevo10 = new Tanque("Fibrocemento", 1000, "no disponible", "Quincenal");
        this.adicionarTanque(nuevo10);

        //General Cisternas Simples
        Cisternas_simples nuevo11 = new Cisternas_simples("cubica", 100, "mal", "Diario");
        this.adicionarCisterna(nuevo11);
        Cisternas_simples nuevo12 = new Cisternas_simples("cubica", 100, "mal", "Diario");
        this.adicionarCisterna(nuevo12);
        Cisternas_simples nuevo13 = new Cisternas_simples("cilindrica", 300, "disponible", "Semanal");
        this.adicionarCisterna(nuevo13);
        Cisternas_simples nuevo14 = new Cisternas_simples("cilindrica", 300, "regular", "Semanal");
        this.adicionarCisterna(nuevo14);
        Cisternas_simples nuevo15 = new Cisternas_simples("cilindrica", 100, "regular", "Quincenal");
        this.adicionarCisterna(nuevo15);
        Cisternas_simples nuevo16 = new Cisternas_simples("cubica", 600, "regular", "Diario");
        this.adicionarCisterna(nuevo16);
        Cisternas_simples nuevo17 = new Cisternas_simples("cilindrica", 600, "disponible", "Quincenal");
        this.adicionarCisterna(nuevo17);
        Cisternas_simples nuevo18 = new Cisternas_simples("cubica", 100, "disponible", "Diario");
        this.adicionarCisterna(nuevo18);
        Cisternas_simples nuevo19 = new Cisternas_simples("cilindrica", 1000, "mal", "Quincenal");
        this.adicionarCisterna(nuevo19);
        Cisternas_simples nuevo20 = new Cisternas_simples("cubica", 1000, "disponible", "Semanal");
        this.adicionarCisterna(nuevo20);

        //General Cisternas Compuestas
        Cisternas_compuestas nuevo21 = new Cisternas_compuestas(1, 100, "mal", "Diario");
        this.adicionarCisterna(nuevo21);
        Cisternas_compuestas nuevo22 = new Cisternas_compuestas(2, 100, "regular", "Semanal");
        this.adicionarCisterna(nuevo22);
        Cisternas_compuestas nuevo23 = new Cisternas_compuestas(3, 300, "regular", "Semanal");
        this.adicionarCisterna(nuevo23);
        Cisternas_compuestas nuevo24 = new Cisternas_compuestas(4, 300, "mal", "Diario");
        this.adicionarCisterna(nuevo24);
        Cisternas_compuestas nuevo25 = new Cisternas_compuestas(5, 100, "regular", "Diario");
        this.adicionarCisterna(nuevo25);
        Cisternas_compuestas nuevo26 = new Cisternas_compuestas(6, 600, "disponible", "Quincenal");
        this.adicionarCisterna(nuevo26);
        Cisternas_compuestas nuevo27 = new Cisternas_compuestas(7, 600, "regular", "Semanal");
        this.adicionarCisterna(nuevo27);
        Cisternas_compuestas nuevo28 = new Cisternas_compuestas(8, 100, "disponible", "Quincenal");
        this.adicionarCisterna(nuevo28);
        Cisternas_compuestas nuevo29 = new Cisternas_compuestas(9, 1000, "regular", "Semanal");
        this.adicionarCisterna(nuevo29);
        Cisternas_compuestas nuevo30 = new Cisternas_compuestas(10, 1000, "regular", "Semanal");
        this.adicionarCisterna(nuevo30);

        //General Bombas de Agua
        Bombas_de_agua nuevo31 = new Bombas_de_agua("disponible", 100, 10);
        this.adicionarBomba(nuevo31);
        Bombas_de_agua nuevo32 = new Bombas_de_agua("disponible", 200, 5);
        this.adicionarBomba(nuevo32);
        Bombas_de_agua nuevo33 = new Bombas_de_agua("regular", 500, 3);
        this.adicionarBomba(nuevo33);
        Bombas_de_agua nuevo34 = new Bombas_de_agua("mal", 600, 2);
        this.adicionarBomba(nuevo34);
        Bombas_de_agua nuevo35 = new Bombas_de_agua("regular", 100, 2);
        this.adicionarBomba(nuevo35);

        //General Turbinas
        Turbina nuevo36 = new Turbina("disponible", 100, 500);
        this.adicionarTurbina(nuevo36);
        Turbina nuevo37 = new Turbina("disponible", 200, 500);
        this.adicionarTurbina(nuevo37);
        Turbina nuevo38 = new Turbina("mal", 500, 100);
        this.adicionarTurbina(nuevo38);
        Turbina nuevo39 = new Turbina("regular", 100, 700);
        this.adicionarTurbina(nuevo39);
        Turbina nuevo40 = new Turbina("disponible", 300, 100);
        this.adicionarTurbina(nuevo40);

    }

    public static void main(String[] args) {
        // TODO code application logic here
    }


}
