/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Clases;

/**
 *
 * @author CasinerO
 */
public class Cisternas_simples extends Cisterna{
    
    private String forma;

    public Cisternas_simples(String forma, int capacidad, String estado, String tipo_abasto) {
        super(capacidad, estado, tipo_abasto);
        this.forma = forma;
    }   

    public String getForma() {
        return forma;
    }

    public void setForma(String forma) {
        this.forma = forma;
    }
    
    
}
