/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Clases;

/**
 *
 * @author CasinerO
 */
public class Cisternas_compuestas extends Cisterna{
    
    private int cantidad_compartimientos;

    public Cisternas_compuestas(int cantidad_compartimientos, int capacidad, String estado, String tipo_abasto) {
        super(capacidad, estado, tipo_abasto);
        this.cantidad_compartimientos = cantidad_compartimientos;
    }

    public int getCantidad_compartimientos() {
        return cantidad_compartimientos;
    }

    public void setCantidad_compartimientos(int cantidad_compartimientos) {
        this.cantidad_compartimientos = cantidad_compartimientos;
    } 
    
    public String cantidadCompartimientosToString(){
        
        return "" + cantidad_compartimientos +"";
    }
    
}
