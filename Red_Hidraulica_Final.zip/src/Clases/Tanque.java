/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import red_hidraulica_final.Red_Hidraulica_Final;

/**
 *
 * @author CasinerO
 */
public class Tanque extends Deposito {
    
    private String tipo_material;

    public Tanque(String tipo_material, int capacidad, String estado, String tipo_abasto) {
        super(capacidad, estado, tipo_abasto);        
        this.tipo_material = tipo_material;
    }


    public String getTipo_material() {
        return this.tipo_material;
    }

    public void setTipo_material(String tipo_material) {
        this.tipo_material = tipo_material;
    }
    
    public String tipoMaterialToString(){
        
        return "" + tipo_material +"";
    }

}
