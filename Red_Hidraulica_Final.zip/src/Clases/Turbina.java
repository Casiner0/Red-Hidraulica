/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Clases;

/**
 *
 * @author CasinerO
 */
public class Turbina {
    
    private String estado;
    private int regimen;
    private int fuerza; 
    

    public Turbina(String estado, int régimen, int fuerza) {
        this.estado = estado;
        this.regimen = régimen;
        this.fuerza = fuerza;
    }  

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public int getRegimen() {
        return regimen;
    }

    public void setRégimen(int regimen) {
        this.regimen = regimen;
    }

    public int getFuerza() {
        return fuerza;
    }

    public void setFuerza(int fuerza) {
        this.fuerza = fuerza;
    }
    
    public String getRegimenToString() {
        return "" + regimen+ "";
    }

    public String getFuerzaToString() {
        return "" + fuerza+ "";
    }
    
    
}
