/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author CasinerO
 */
public class Bombas_de_agua {

    private String estado;
    private int regimen;
    private int tiempo_bombeo;

    public Bombas_de_agua(String estado, int regimen, int tiempo_bombeo) {
        this.estado = estado;
        this.regimen = regimen;
        this.tiempo_bombeo = tiempo_bombeo;
    }

    public Bombas_de_agua() {

    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getRegimen() {
        return regimen;
    }
    
    public String getRegimenToString() {
        return ""+ regimen + "";
    }

    public void setRegimen(int regimen) {
        this.regimen = regimen;
    }

    public int getTiempo_bombeo() {
        return tiempo_bombeo;
    }
    
    public String getTiempoBombeoToString() {
        return ""+ tiempo_bombeo + "";
    }

    public void setTiempo_bombeo(int tiempo_bombeo) {
        this.tiempo_bombeo = tiempo_bombeo;
    }

    
}
