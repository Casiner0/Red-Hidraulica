/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Clases;

/**
 *
 * @author CasinerO
 */
public class Deposito {
    
    private int capacidad;
    private String estado;
    private String tipo_abasto;

    public Deposito(int capacidad, String estado, String tipo_abasto) {
        this.capacidad = capacidad;
        this.estado = estado;
        this.tipo_abasto = tipo_abasto;
    }
    
    public Deposito() {
        
    }
    
    

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getTipo_abasto() {
        return tipo_abasto;
    }

    public void setTipo_abasto(String tipo_abasto) {
        this.tipo_abasto = tipo_abasto;
    }
    
    public String capacidadToString(){
        
        return "" + capacidad +"";
    }
    
}
