/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author CasinerO
 */
public class Cisterna extends Deposito {
    

    public Cisterna(int capacidad, String estado, String tipo_abasto) {
        super(capacidad, estado, tipo_abasto);
    }
  
}
